//  Natasha Holloran Lab 18, 2024/11/28 //

let billAmount = Number(prompt(" Please enter a bill amount: "));
let tipPercentage = Number(prompt(" Please enter a tip percentage: "));
let sum = (billAmount * tipPercentage) / 100;
let total = sum + billAmount;

alert(" The total bill Amount is " + total);
